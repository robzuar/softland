<?php

namespace AppBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Pagerfanta\Pagerfanta;
use Pagerfanta\Adapter\DoctrineORMAdapter;
use Pagerfanta\View\TwitterBootstrap3View;

use AppBundle\Entity\Complaint;

/**
 * Complaint controller.
 *
 * @Route("/complaint")
 */
class ComplaintController extends Controller
{
    /**
     * Lists all Complaint entities.
     *
     * @Route("/", name="complaint")
     * @Method("GET")
     */
    public function indexAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $queryBuilder = $em->getRepository('AppBundle:Complaint')->createQueryBuilder('e');

        list($filterForm, $queryBuilder) = $this->filter($queryBuilder, $request);
        list($complaints, $pagerHtml) = $this->paginator($queryBuilder, $request);
        
        $totalOfRecordsString = $this->getTotalOfRecordsString($queryBuilder, $request);

        return $this->render('complaint/index.html.twig', array(
            'complaints' => $complaints,
            'pagerHtml' => $pagerHtml,
            'filterForm' => $filterForm->createView(),
            'totalOfRecordsString' => $totalOfRecordsString,

        ));
    }


    /**
    * Create filter form and process filter request.
    *
    */
    protected function filter($queryBuilder, $request)
    {
        $filterForm = $this->createForm('AppBundle\Form\ComplaintFilterType');

        // Bind values from the request
        $filterForm->handleRequest($request);

        if ($filterForm->isValid()) {
            // Build the query from the given form object
            $this->get('petkopara_multi_search.builder')->searchForm( $queryBuilder, $filterForm->get('search'));
        }

        return array($filterForm, $queryBuilder);
    }

    /**
    * Get results from paginator and get paginator view.
    *
    */
    protected function paginator($queryBuilder, Request $request)
    {
        //sorting
        $sortCol = $queryBuilder->getRootAlias().'.'.$request->get('pcg_sort_col', 'id');
        $queryBuilder->orderBy($sortCol, $request->get('pcg_sort_order', 'desc'));
        // Paginator
        $adapter = new DoctrineORMAdapter($queryBuilder);
        $pagerfanta = new Pagerfanta($adapter);
        $pagerfanta->setMaxPerPage($request->get('pcg_show' , 10));

        try {
            $pagerfanta->setCurrentPage($request->get('pcg_page', 1));
        } catch (\Pagerfanta\Exception\OutOfRangeCurrentPageException $ex) {
            $pagerfanta->setCurrentPage(1);
        }
        
        $entities = $pagerfanta->getCurrentPageResults();

        // Paginator - route generator
        $me = $this;
        $routeGenerator = function($page) use ($me, $request)
        {
            $requestParams = $request->query->all();
            $requestParams['pcg_page'] = $page;
            return $me->generateUrl('complaint', $requestParams);
        };

        // Paginator - view
        $view = new TwitterBootstrap3View();
        $pagerHtml = $view->render($pagerfanta, $routeGenerator, array(
            'proximity' => 3,
            'prev_message' => 'previous',
            'next_message' => 'next',
        ));

        return array($entities, $pagerHtml);
    }
    
    
    
    /*
     * Calculates the total of records string
     */
    protected function getTotalOfRecordsString($queryBuilder, $request) {
        $totalOfRecords = $queryBuilder->select('COUNT(e.id)')->getQuery()->getSingleScalarResult();
        $show = $request->get('pcg_show', 10);
        $page = $request->get('pcg_page', 1);

        $startRecord = ($show * ($page - 1)) + 1;
        $endRecord = $show * $page;

        if ($endRecord > $totalOfRecords) {
            $endRecord = $totalOfRecords;
        }
        return "Showing $startRecord - $endRecord of $totalOfRecords Records.";
    }
    
    

    /**
     * Displays a form to create a new Complaint entity.
     *
     * @Route("/new", name="complaint_new")
     * @Method({"GET", "POST"})
     */
    public function newAction(Request $request)
    {
    
        $complaint = new Complaint();
        $form   = $this->createForm('AppBundle\Form\ComplaintType', $complaint);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($complaint);
            $em->flush();
            
            $editLink = $this->generateUrl('complaint_edit', array('id' => $complaint->getId()));
            $this->get('session')->getFlashBag()->add('success', "<a href='$editLink'>New complaint was created successfully.</a>" );
            
            $nextAction=  $request->get('submit') == 'save' ? 'complaint' : 'complaint_new';
            return $this->redirectToRoute($nextAction);
        }
        return $this->render('complaint/new.html.twig', array(
            'complaint' => $complaint,
            'form'   => $form->createView(),
        ));
    }
    

    /**
     * Finds and displays a Complaint entity.
     *
     * @Route("/{id}", name="complaint_show")
     * @Method("GET")
     */
    public function showAction(Complaint $complaint)
    {
        $deleteForm = $this->createDeleteForm($complaint);
        return $this->render('complaint/show.html.twig', array(
            'complaint' => $complaint,
            'delete_form' => $deleteForm->createView(),
        ));
    }
    
    

    /**
     * Displays a form to edit an existing Complaint entity.
     *
     * @Route("/{id}/edit", name="complaint_edit")
     * @Method({"GET", "POST"})
     */
    public function editAction(Request $request, Complaint $complaint)
    {
        $deleteForm = $this->createDeleteForm($complaint);
        $editForm = $this->createForm('AppBundle\Form\ComplaintType', $complaint);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($complaint);
            $em->flush();
            
            $this->get('session')->getFlashBag()->add('success', 'Edited Successfully!');
            return $this->redirectToRoute('complaint_edit', array('id' => $complaint->getId()));
        }
        return $this->render('complaint/edit.html.twig', array(
            'complaint' => $complaint,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }
    
    

    /**
     * Deletes a Complaint entity.
     *
     * @Route("/{id}", name="complaint_delete")
     * @Method("DELETE")
     */
    public function deleteAction(Request $request, Complaint $complaint)
    {
    
        $form = $this->createDeleteForm($complaint);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($complaint);
            $em->flush();
            $this->get('session')->getFlashBag()->add('success', 'The Complaint was deleted successfully');
        } else {
            $this->get('session')->getFlashBag()->add('error', 'Problem with deletion of the Complaint');
        }
        
        return $this->redirectToRoute('complaint');
    }
    
    /**
     * Creates a form to delete a Complaint entity.
     *
     * @param Complaint $complaint The Complaint entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Complaint $complaint)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('complaint_delete', array('id' => $complaint->getId())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
    
    /**
     * Delete Complaint by id
     *
     * @Route("/delete/{id}", name="complaint_by_id_delete")
     * @Method("GET")
     */
    public function deleteByIdAction(Complaint $complaint){
        $em = $this->getDoctrine()->getManager();
        
        try {
            $em->remove($complaint);
            $em->flush();
            $this->get('session')->getFlashBag()->add('success', 'The Complaint was deleted successfully');
        } catch (Exception $ex) {
            $this->get('session')->getFlashBag()->add('error', 'Problem with deletion of the Complaint');
        }

        return $this->redirect($this->generateUrl('complaint'));

    }
    

    /**
    * Bulk Action
    * @Route("/bulk-action/", name="complaint_bulk_action")
    * @Method("POST")
    */
    public function bulkAction(Request $request)
    {
        $ids = $request->get("ids", array());
        $action = $request->get("bulk_action", "delete");

        if ($action == "delete") {
            try {
                $em = $this->getDoctrine()->getManager();
                $repository = $em->getRepository('AppBundle:Complaint');

                foreach ($ids as $id) {
                    $complaint = $repository->find($id);
                    $em->remove($complaint);
                    $em->flush();
                }

                $this->get('session')->getFlashBag()->add('success', 'complaints was deleted successfully!');

            } catch (Exception $ex) {
                $this->get('session')->getFlashBag()->add('error', 'Problem with deletion of the complaints ');
            }
        }

        return $this->redirect($this->generateUrl('complaint'));
    }
    

}
