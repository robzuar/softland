<?php

namespace AppBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Pagerfanta\Pagerfanta;
use Pagerfanta\Adapter\DoctrineORMAdapter;
use Pagerfanta\View\TwitterBootstrap3View;

use AppBundle\Entity\TypeComplaint;

/**
 * TypeComplaint controller.
 *
 * @Route("/typecomplaint")
 */
class TypeComplaintController extends Controller
{
    /**
     * Lists all TypeComplaint entities.
     *
     * @Route("/", name="typecomplaint")
     * @Method("GET")
     */
    public function indexAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $queryBuilder = $em->getRepository('AppBundle:TypeComplaint')->createQueryBuilder('e');

        list($filterForm, $queryBuilder) = $this->filter($queryBuilder, $request);
        list($typeComplaints, $pagerHtml) = $this->paginator($queryBuilder, $request);
        
        $totalOfRecordsString = $this->getTotalOfRecordsString($queryBuilder, $request);

        return $this->render('typecomplaint/index.html.twig', array(
            'typeComplaints' => $typeComplaints,
            'pagerHtml' => $pagerHtml,
            'filterForm' => $filterForm->createView(),
            'totalOfRecordsString' => $totalOfRecordsString,

        ));
    }


    /**
    * Create filter form and process filter request.
    *
    */
    protected function filter($queryBuilder, $request)
    {
        $filterForm = $this->createForm('AppBundle\Form\TypeComplaintFilterType');

        // Bind values from the request
        $filterForm->handleRequest($request);

        if ($filterForm->isValid()) {
            // Build the query from the given form object
            $this->get('petkopara_multi_search.builder')->searchForm( $queryBuilder, $filterForm->get('search'));
        }

        return array($filterForm, $queryBuilder);
    }

    /**
    * Get results from paginator and get paginator view.
    *
    */
    protected function paginator($queryBuilder, Request $request)
    {
        //sorting
        $sortCol = $queryBuilder->getRootAlias().'.'.$request->get('pcg_sort_col', 'id');
        $queryBuilder->orderBy($sortCol, $request->get('pcg_sort_order', 'desc'));
        // Paginator
        $adapter = new DoctrineORMAdapter($queryBuilder);
        $pagerfanta = new Pagerfanta($adapter);
        $pagerfanta->setMaxPerPage($request->get('pcg_show' , 10));

        try {
            $pagerfanta->setCurrentPage($request->get('pcg_page', 1));
        } catch (\Pagerfanta\Exception\OutOfRangeCurrentPageException $ex) {
            $pagerfanta->setCurrentPage(1);
        }
        
        $entities = $pagerfanta->getCurrentPageResults();

        // Paginator - route generator
        $me = $this;
        $routeGenerator = function($page) use ($me, $request)
        {
            $requestParams = $request->query->all();
            $requestParams['pcg_page'] = $page;
            return $me->generateUrl('typecomplaint', $requestParams);
        };

        // Paginator - view
        $view = new TwitterBootstrap3View();
        $pagerHtml = $view->render($pagerfanta, $routeGenerator, array(
            'proximity' => 3,
            'prev_message' => 'previous',
            'next_message' => 'next',
        ));

        return array($entities, $pagerHtml);
    }
    
    
    
    /*
     * Calculates the total of records string
     */
    protected function getTotalOfRecordsString($queryBuilder, $request) {
        $totalOfRecords = $queryBuilder->select('COUNT(e.id)')->getQuery()->getSingleScalarResult();
        $show = $request->get('pcg_show', 10);
        $page = $request->get('pcg_page', 1);

        $startRecord = ($show * ($page - 1)) + 1;
        $endRecord = $show * $page;

        if ($endRecord > $totalOfRecords) {
            $endRecord = $totalOfRecords;
        }
        return "Showing $startRecord - $endRecord of $totalOfRecords Records.";
    }
    
    

    /**
     * Displays a form to create a new TypeComplaint entity.
     *
     * @Route("/new", name="typecomplaint_new")
     * @Method({"GET", "POST"})
     */
    public function newAction(Request $request)
    {
    
        $typeComplaint = new TypeComplaint();
        $form   = $this->createForm('AppBundle\Form\TypeComplaintType', $typeComplaint);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($typeComplaint);
            $em->flush();
            
            $editLink = $this->generateUrl('typecomplaint_edit', array('id' => $typeComplaint->getId()));
            $this->get('session')->getFlashBag()->add('success', "<a href='$editLink'>New typeComplaint was created successfully.</a>" );
            
            $nextAction=  $request->get('submit') == 'save' ? 'typecomplaint' : 'typecomplaint_new';
            return $this->redirectToRoute($nextAction);
        }
        return $this->render('typecomplaint/new.html.twig', array(
            'typeComplaint' => $typeComplaint,
            'form'   => $form->createView(),
        ));
    }
    

    /**
     * Finds and displays a TypeComplaint entity.
     *
     * @Route("/{id}", name="typecomplaint_show")
     * @Method("GET")
     */
    public function showAction(TypeComplaint $typeComplaint)
    {
        $deleteForm = $this->createDeleteForm($typeComplaint);
        return $this->render('typecomplaint/show.html.twig', array(
            'typeComplaint' => $typeComplaint,
            'delete_form' => $deleteForm->createView(),
        ));
    }
    
    

    /**
     * Displays a form to edit an existing TypeComplaint entity.
     *
     * @Route("/{id}/edit", name="typecomplaint_edit")
     * @Method({"GET", "POST"})
     */
    public function editAction(Request $request, TypeComplaint $typeComplaint)
    {
        $deleteForm = $this->createDeleteForm($typeComplaint);
        $editForm = $this->createForm('AppBundle\Form\TypeComplaintType', $typeComplaint);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($typeComplaint);
            $em->flush();
            
            $this->get('session')->getFlashBag()->add('success', 'Edited Successfully!');
            return $this->redirectToRoute('typecomplaint_edit', array('id' => $typeComplaint->getId()));
        }
        return $this->render('typecomplaint/edit.html.twig', array(
            'typeComplaint' => $typeComplaint,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }
    
    

    /**
     * Deletes a TypeComplaint entity.
     *
     * @Route("/{id}", name="typecomplaint_delete")
     * @Method("DELETE")
     */
    public function deleteAction(Request $request, TypeComplaint $typeComplaint)
    {
    
        $form = $this->createDeleteForm($typeComplaint);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($typeComplaint);
            $em->flush();
            $this->get('session')->getFlashBag()->add('success', 'The TypeComplaint was deleted successfully');
        } else {
            $this->get('session')->getFlashBag()->add('error', 'Problem with deletion of the TypeComplaint');
        }
        
        return $this->redirectToRoute('typecomplaint');
    }
    
    /**
     * Creates a form to delete a TypeComplaint entity.
     *
     * @param TypeComplaint $typeComplaint The TypeComplaint entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(TypeComplaint $typeComplaint)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('typecomplaint_delete', array('id' => $typeComplaint->getId())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
    
    /**
     * Delete TypeComplaint by id
     *
     * @Route("/delete/{id}", name="typecomplaint_by_id_delete")
     * @Method("GET")
     */
    public function deleteByIdAction(TypeComplaint $typeComplaint){
        $em = $this->getDoctrine()->getManager();
        
        try {
            $em->remove($typeComplaint);
            $em->flush();
            $this->get('session')->getFlashBag()->add('success', 'The TypeComplaint was deleted successfully');
        } catch (Exception $ex) {
            $this->get('session')->getFlashBag()->add('error', 'Problem with deletion of the TypeComplaint');
        }

        return $this->redirect($this->generateUrl('typecomplaint'));

    }
    

    /**
    * Bulk Action
    * @Route("/bulk-action/", name="typecomplaint_bulk_action")
    * @Method("POST")
    */
    public function bulkAction(Request $request)
    {
        $ids = $request->get("ids", array());
        $action = $request->get("bulk_action", "delete");

        if ($action == "delete") {
            try {
                $em = $this->getDoctrine()->getManager();
                $repository = $em->getRepository('AppBundle:TypeComplaint');

                foreach ($ids as $id) {
                    $typeComplaint = $repository->find($id);
                    $em->remove($typeComplaint);
                    $em->flush();
                }

                $this->get('session')->getFlashBag()->add('success', 'typeComplaints was deleted successfully!');

            } catch (Exception $ex) {
                $this->get('session')->getFlashBag()->add('error', 'Problem with deletion of the typeComplaints ');
            }
        }

        return $this->redirect($this->generateUrl('typecomplaint'));
    }
    

}
