<?php
namespace AppBundle\Controller;

use ClassesWithParents\D;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use CMEN\GoogleChartsBundle\GoogleCharts\Charts\PieChart;
/**
 * Class DefaultController
 * @package AppBundle\Controller
 *
 * @author Roberto Zuñiga Araya <roberto.zuniga.araya@gmail.com>
 */
class DefaultController extends Controller
{

    /**
     * @return \Symfony\Component\HttpFoundation\Response
     * @Route("/", name="homepage")
     */
    public function indexAction()
    {
        $em = $this->getDoctrine()->getManager();


        $today = new \DateTime();
        $aWeekAgo = $today->modify('- 7 day');
        $today = $today->format('Y-m-d');

        $week_start = new \DateTime('last Sunday');
        $week_start = $week_start->format('Y-m-d');
        $week_end = new \DateTime('next Sunday');
        $week_end = $week_end->format('Y-m-d');
        $month_start = new \DateTime('first day of this month');
        $month_start = $month_start->format('Y-m-d');
        $month_end = new \DateTime('last day of this month');
        $month_end = $month_end->format('Y-m-d');
        $year_start = new \DateTime('first day of January');
        $year_start = $year_start->format('Y-m-d');
        $year_end = new \DateTime('last day of December');
        $year_end = $year_end->format('Y-m-d');

        $cedibles = $em->getRepository('AppBundle:BillControl')->getCountBetween($today, $today);
        $datesMonthOne = $em->getRepository('AppBundle:Bill')->getCountBetween(1, $month_start, $month_end);
        $datesYearOne = $em->getRepository('AppBundle:Bill')->getCountBetween(1, $year_start, $year_end);
        $datesWeekOne = $em->getRepository('AppBundle:Bill')->getCountBetween(1, $week_start, $week_end);
        $datesMonthZero = $em->getRepository('AppBundle:Bill')->getCountBetween(0, $month_start, $month_end);
        $datesYearZero = $em->getRepository('AppBundle:Bill')->getCountBetween(0, $year_start, $year_end);
        $datesWeekZero = $em->getRepository('AppBundle:Bill')->getCountBetween(0, $week_start, $week_end);
        $dateTodayOne = $em->getRepository('AppBundle:Bill')->getCountBetween(1, $today, $today);
        $dateTodayZero = $em->getRepository('AppBundle:Bill')->getCountBetween(0, $today, $today);
        /*
        dump($datesMonthOne);
        dump($datesYearOne);
        dump($datesWeekOne);
        dump($datesMonthZero);
        die();
        */
        $percToday = (count($dateTodayOne) + count($dateTodayZero));
        if($percToday  == 0){
            $percToday = 0;
        }else{
            $percToday = (count($dateTodayOne) * 100) / $percToday;
        }
        $percWeek = (count($datesWeekOne) + count($datesWeekZero));
        if($percWeek  == 0){
            $percWeek = 0;
        }else{
            $percWeek = (count($datesWeekOne) * 100) / $percWeek;
        }
        $percMonth = (count($datesMonthOne) + count($datesMonthZero));
        if($percMonth  == 0){
            $percMonth = 0;
        }else {
            $percMonth = (count($datesMonthOne) * 100) / $percMonth;
        }
        $percYear = (count($datesYearOne) + count($datesYearZero));
        if($percYear  == 0){
            $percYear = 0;
        }else {
            $percYear = (count($datesYearOne) * 100) / $percYear;
        }

        $enero = new \DateTime('2000-01-01');
        $sql = $em->getRepository('AppBundle:Bill')->getCountBetween($enero, $today);
        //$sql2 = $em->getRepository('AppBundle:Bill')->getCountBetween(0, $enero, $today);

        //$this->lineChart($sql);


        return $this->render('default/index.html.twig',
            [
                'cedibles'  => $cedibles,
                'datesMonthOne'     => $datesMonthOne,
                'datesMonthZero'     => $datesMonthZero,
                'porcMonth'         => $percMonth,
                'datesYearOne'     => $datesYearOne,
                'datesYearZero'     => $datesYearZero,
                'porcYear'         => $percYear,
                'datesWeekOne'     => $datesWeekOne,
                'datesWeekZero'     => $datesWeekZero,
                'porcWeek'         => $percWeek,
                'dateTodayOne'     => $dateTodayOne,
                'dateTodayZero'     => $dateTodayZero,
                'porcToday'         => $percToday,

            ]
        );


    }

    /**
     * @return \Symfony\Component\HttpFoundation\Response
     * @Route("/", name="redirect")
     */
    public function redirectAction()
    {
        return $this->render('default/index.html.twig');
    }

    /**
     * Lists all Cargo entities.
     *
     * @Route("/error_errorIE", name="default_error_errorIE")
     * @Method("GET")
     * @Template()
     */
    public function errorIEAction(Request $request)
    {
        return array('template' => "empty");
    }


    /**
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     * @Route("/chart", name="charts")
     * @Method({"GET", "POST"})
     */
    public function chartsAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();

        $routes = $em->getRepository('AppBundle:Route')->findBy(['enabled' => true]);
        $clients = $em->getRepository('AppBundle:Client')->findBy(['enabled' => true]);
        $vehicle = $em->getRepository('AppBundle:Vehicle')->findBy(['enabled' => true]);
        //$routes = $em->getRepository('AppBundle:Route')->findBy(['enabled' => true]);

        if ($request->get('status_action') == 'complete') {
            //dump($request);die();

            $datesRequest = $request->request->get('advance-daterange');
            $routesRequest = $request->request->get('route');
            $clientsRequest = $request->request->get('client');
            $vehicleRequest = $request->request->get('vechicle');

            //dump($datesRequest);die();
            $datesRequest = explode(' - ', $datesRequest);
            $begin = $datesRequest[0];
            $end = $datesRequest[1];
            $begin = new \DateTime($begin);
            $begin = $begin->format('y-m-d');
            $end = new \DateTime($end);
            $end = $end->format('Y-m-d');

            //dump($begin);dump($end);die();

            $var = "";
            $line = "";
            if($routesRequest){
                $line = 'route';
                $var = $routesRequest;
            }elseif($clientsRequest){
                $line = 'client';
                $var = $clientsRequest;
            }elseif($vehicleRequest){
                $line = 'vehicle';
                $var = $vehicleRequest;
            }

            $sql = $em->getRepository('AppBundle:Bill')->getCountBetweenVal($line, $var, $begin, $end);


            //dump($sql);die();
            /*
           dump($datesRequest);
           dump($routesRequest);
           dump($clientsRequest);
           dump($vehicleRequest);
           die();
           */

            $pieChart = $this->pieChart($sql);

            return $this->render('default/charts.html.twig',
                [
                    'routes'        => $routes,
                    'vehicles'      => $vehicle,
                    'clients'       => $clients,
                    'details'       => $sql,
                    'piechart'      => $pieChart
                ]);
        }
        return $this->render('default/charts.html.twig',
            [
                'routes'        => $routes,
                'vehicles'      => $vehicle,
                'clients'       => $clients
            ]);


    }

    public function pieChart($values){
        $complete = 0;
        $parcial = 0;
        foreach ($values as $value){
            if($value->getNsValue() == 1){
                $complete = $complete + 1;
            }else{
                $parcial = $parcial + 1;
            }
        }

        $pieChart = new PieChart();
        $pieChart->getData()->setArrayToDataTable(
            [['Task', 'Hours per Day'],
                ['NS 1',     $complete],
                ['NS 0',      $parcial],
            ]
        );
        $pieChart->getOptions()->setTitle('Nivel de Servicio');
        $pieChart->getOptions()->setHeight(500);
        $pieChart->getOptions()->setWidth(900);
        $pieChart->getOptions()->getTitleTextStyle()->setBold(true);
        $pieChart->getOptions()->getTitleTextStyle()->setColor('#009900');
        $pieChart->getOptions()->getTitleTextStyle()->setItalic(true);
        $pieChart->getOptions()->getTitleTextStyle()->setFontName('Arial');
        $pieChart->getOptions()->getTitleTextStyle()->setFontSize(20);

        return $pieChart;
    }

    public function lineChart($values){

        $chart = new LineChart();
        $chart->getData()->setArrayToDataTable([
            ['Month', 'Average Temperature', 'Average Hours of Daylight'],
            [new DateTime('2014-01'),  -.5,  5.7],
            [new DateTime('2014-02'),   .4,  8.7],
            [new DateTime('2014-03'),   .5,   12],
            [new DateTime('2014-04'),  2.9, 15.3],
            [new DateTime('2014-05'),  6.3, 18.6],
            [new DateTime('2014-06'),    9, 20.9],
            [new DateTime('2014-07'), 10.6, 19.8],
            [new DateTime('2014-08'), 10.3, 16.6],
            [new DateTime('2014-09'),  7.4, 13.3],
            [new DateTime('2014-10'),  4.4,  9.9],
            [new DateTime('2014-11'), 1.1,  6.6],
            [new DateTime('2014-12'), -.2,  4.5]
        ]);



        $chart->getOptions()->getChart()
            ->setTitle('Average Temperatures and Daylight in Iceland Throughout the Year');
        $chart->getOptions()
            ->setHeight(400)
            ->setWidth(900)
            ->setSeries([['axis' => 'Temps'], ['axis' => 'Daylight']])
            ->setAxes(['y' => ['Temps' => ['label' => 'Temps (Celsius)'], 'Daylight' => ['label' => 'Daylight']]]);
    }
}
