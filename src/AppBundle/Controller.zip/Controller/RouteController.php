<?php

namespace AppBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Pagerfanta\Pagerfanta;
use Pagerfanta\Adapter\DoctrineORMAdapter;
use Pagerfanta\View\TwitterBootstrap3View;

/**
 * Route controller.
 *
 * @Route("/route")
 */
class RouteController extends Controller
{
    /**
     * Lists all Route entities.
     *
     * @Route("/", name="route")
     * @Method("GET")
     */
    public function indexAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $queryBuilder = $em->getRepository('AppBundle:Route')->createQueryBuilder('e');

        list($filterForm, $queryBuilder) = $this->filter($queryBuilder, $request);
        list($routes, $pagerHtml) = $this->paginator($queryBuilder, $request);
        
        $totalOfRecordsString = $this->getTotalOfRecordsString($queryBuilder, $request);

        return $this->render('route/index.html.twig', array(
            'routes' => $routes,
            'pagerHtml' => $pagerHtml,
            'filterForm' => $filterForm->createView(),
            'totalOfRecordsString' => $totalOfRecordsString,

        ));
    }


    /**
    * Create filter form and process filter request.
    *
    */
    protected function filter($queryBuilder, $request)
    {
        $filterForm = $this->createForm('AppBundle\Form\RouteFilterType');

        // Bind values from the request
        $filterForm->handleRequest($request);

        if ($filterForm->isValid()) {
            // Build the query from the given form object
            $this->get('petkopara_multi_search.builder')->searchForm( $queryBuilder, $filterForm->get('search'));
        }

        return array($filterForm, $queryBuilder);
    }

    /**
    * Get results from paginator and get paginator view.
    *
    */
    protected function paginator($queryBuilder, Request $request)
    {
        //sorting
        $sortCol = $queryBuilder->getRootAlias().'.'.$request->get('pcg_sort_col', 'id');
        $queryBuilder->orderBy($sortCol, $request->get('pcg_sort_order', 'desc'));
        // Paginator
        $adapter = new DoctrineORMAdapter($queryBuilder);
        $pagerfanta = new Pagerfanta($adapter);
        $pagerfanta->setMaxPerPage($request->get('pcg_show' , 10));

        try {
            $pagerfanta->setCurrentPage($request->get('pcg_page', 1));
        } catch (\Pagerfanta\Exception\OutOfRangeCurrentPageException $ex) {
            $pagerfanta->setCurrentPage(1);
        }
        
        $entities = $pagerfanta->getCurrentPageResults();

        // Paginator - route generator
        $me = $this;
        $routeGenerator = function($page) use ($me, $request)
        {
            $requestParams = $request->query->all();
            $requestParams['pcg_page'] = $page;
            return $me->generateUrl('route', $requestParams);
        };

        // Paginator - view
        $view = new TwitterBootstrap3View();
        $pagerHtml = $view->render($pagerfanta, $routeGenerator, array(
            'proximity' => 3,
            'prev_message' => 'previous',
            'next_message' => 'next',
        ));

        return array($entities, $pagerHtml);
    }
    
    
    
    /*
     * Calculates the total of records string
     */
    protected function getTotalOfRecordsString($queryBuilder, $request) {
        $totalOfRecords = $queryBuilder->select('COUNT(e.id)')->getQuery()->getSingleScalarResult();
        $show = $request->get('pcg_show', 10);
        $page = $request->get('pcg_page', 1);

        $startRecord = ($show * ($page - 1)) + 1;
        $endRecord = $show * $page;

        if ($endRecord > $totalOfRecords) {
            $endRecord = $totalOfRecords;
        }
        return "Showing $startRecord - $endRecord of $totalOfRecords Records.";
    }
    
    

    /**
     * Displays a form to create a new Route entity.
     *
     * @Route("/new", name="route_new")
     * @Method({"GET", "POST"})
     */
    public function newAction(Request $request)
    {
    
        $route = new Route();
        $form   = $this->createForm('AppBundle\Form\RouteType', $route);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($route);
            $em->flush();
            
            $editLink = $this->generateUrl('route_edit', array('id' => $route->getId()));
            $this->get('session')->getFlashBag()->add('success', "<a href='$editLink'>New route was created successfully.</a>" );
            
            $nextAction=  $request->get('submit') == 'save' ? 'route' : 'route_new';
            return $this->redirectToRoute($nextAction);
        }
        return $this->render('route/new.html.twig', array(
            'route' => $route,
            'form'   => $form->createView(),
        ));
    }
    

    /**
     * Finds and displays a Route entity.
     *
     * @Route("/{id}", name="route_show")
     * @Method("GET")
     */
    public function showAction(Route $route)
    {
        $deleteForm = $this->createDeleteForm($route);
        return $this->render('route/show.html.twig', array(
            'route' => $route,
            'delete_form' => $deleteForm->createView(),
        ));
    }
    
    

    /**
     * Displays a form to edit an existing Route entity.
     *
     * @Route("/{id}/edit", name="route_edit")
     * @Method({"GET", "POST"})
     */
    public function editAction(Request $request, Route $route)
    {
        $deleteForm = $this->createDeleteForm($route);
        $editForm = $this->createForm('AppBundle\Form\RouteType', $route);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($route);
            $em->flush();
            
            $this->get('session')->getFlashBag()->add('success', 'Edited Successfully!');
            return $this->redirectToRoute('route_edit', array('id' => $route->getId()));
        }
        return $this->render('route/edit.html.twig', array(
            'route' => $route,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }
    
    

    /**
     * Deletes a Route entity.
     *
     * @Route("/{id}", name="route_delete")
     * @Method("DELETE")
     */
    public function deleteAction(Request $request, Route $route)
    {
    
        $form = $this->createDeleteForm($route);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($route);
            $em->flush();
            $this->get('session')->getFlashBag()->add('success', 'The Route was deleted successfully');
        } else {
            $this->get('session')->getFlashBag()->add('error', 'Problem with deletion of the Route');
        }
        
        return $this->redirectToRoute('route');
    }
    
    /**
     * Creates a form to delete a Route entity.
     *
     * @param Route $route The Route entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Route $route)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('route_delete', array('id' => $route->getId())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
    
    /**
     * Delete Route by id
     *
     * @Route("/delete/{id}", name="route_by_id_delete")
     * @Method("GET")
     */
    public function deleteByIdAction(Route $route){
        $em = $this->getDoctrine()->getManager();
        
        try {
            $em->remove($route);
            $em->flush();
            $this->get('session')->getFlashBag()->add('success', 'The Route was deleted successfully');
        } catch (Exception $ex) {
            $this->get('session')->getFlashBag()->add('error', 'Problem with deletion of the Route');
        }

        return $this->redirect($this->generateUrl('route'));

    }
    

    /**
    * Bulk Action
    * @Route("/bulk-action/", name="route_bulk_action")
    * @Method("POST")
    */
    public function bulkAction(Request $request)
    {
        $ids = $request->get("ids", array());
        $action = $request->get("bulk_action", "delete");

        if ($action == "delete") {
            try {
                $em = $this->getDoctrine()->getManager();
                $repository = $em->getRepository('AppBundle:Route');

                foreach ($ids as $id) {
                    $route = $repository->find($id);
                    $em->remove($route);
                    $em->flush();
                }

                $this->get('session')->getFlashBag()->add('success', 'routes was deleted successfully!');

            } catch (Exception $ex) {
                $this->get('session')->getFlashBag()->add('error', 'Problem with deletion of the routes ');
            }
        }

        return $this->redirect($this->generateUrl('route'));
    }
    

}
